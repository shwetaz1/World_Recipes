const firebaseConfig = {
    apiKey: "AIzaSyDIwSwi2szr6UU2MF1xzl3Vx54KbSzM3pc",
  authDomain: "world-recipes-e907c.firebaseapp.com",
  projectId: "world-recipes-e907c",
  storageBucket: "world-recipes-e907c.appspot.com",
  messagingSenderId: "539325790383",
  appId: "1:539325790383:web:f7727dbb1f49bee4f43c5a",
  measurementId: "G-7PK3YYLGX2"
  };